package com.example.utmnavigator

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.pm.PackageManager
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var geoRequest: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            setGeolocationEnabled(true)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false)
                } else {
                    geoRequest = callback
                    geoOrigin = origin
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 9)
                }
            }
        }
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 9) {
            val ok = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            geoRequest?.invoke(geoOrigin, ok, false)
            if (!ok) Toast.makeText(this, "برای GPS اجازه مکان لازم است", Toast.LENGTH_LONG).show()
            geoRequest = null
            geoOrigin = null
        }
    }
}
