# Change log – Ownership readiness
- Added an in-app About / copyright notice for attribution to Alireza Behnam.
- Bumped Android versionCode to 5 and versionName to 1.4.
- Added Persian ownership and registration preparation file.
- This does not constitute a trademark registration or software certificate.
