package com.example.utmnavigator

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var geoRequest: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private var pendingExportContent: String? = null
    private var pendingExportMime: String = "application/octet-stream"

    inner class ExportBridge {
        @JavascriptInterface
        fun saveFile(filename: String, mime: String, content: String) {
            pendingExportContent = content
            pendingExportMime = mime
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mime
                        putExtra(Intent.EXTRA_TITLE, filename)
                    }
                    startActivityForResult(intent, 42)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "باز کردن پنجره ذخیره فایل ناموفق بود", Toast.LENGTH_LONG).show()
                    pendingExportContent = null
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            safeBrowsingEnabled = true
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            setGeolocationEnabled(true)
        }
        web.addJavascriptInterface(ExportBridge(), "AndroidExport")
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false)
                } else {
                    geoRequest = callback
                    geoOrigin = origin
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 9)
                }
            }
        }
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42) {
            if (resultCode == RESULT_OK && data?.data != null) {
                val uri: Uri = data.data!!
                try {
                    val content = pendingExportContent ?: throw Exception("داده خروجی در دسترس نیست")
                    contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                        ?: throw Exception("فایل قابل نوشتن نیست")
                    Toast.makeText(this, "فایل با موفقیت ذخیره شد", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ذخیره فایل ناموفق: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            pendingExportContent = null
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 9) {
            val ok = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            geoRequest?.invoke(geoOrigin, ok, false)
            if (!ok) Toast.makeText(this, "برای GPS اجازه مکان لازم است", Toast.LENGTH_LONG).show()
            geoRequest = null
            geoOrigin = null
        }
    }
}
