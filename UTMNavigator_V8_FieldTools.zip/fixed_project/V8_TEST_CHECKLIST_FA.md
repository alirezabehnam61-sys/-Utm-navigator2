# چک‌لیست تست V8

- [x] بررسی Syntax JavaScript با Node.js (`node --check`)
- [x] تست عددی رفت و برگشت UTM/LatLon برای Lat=32, Lon=53, Zone=39 (خطا زیر 1e-6 درجه)
- [x] تست محاسبه فاصله و آزیموت دو نقطه با فاصله 100m در E و 100m در N
- [ ] Build APK در GitHub Actions
- [ ] بازشدن اپ روی Android واقعی
- [ ] مجوز GPS و دریافت مختصات
- [ ] فعال‌شدن سنسور قطب‌نما و heading معتبر
- [ ] Stakeout در میدان و مقایسه با جهت/فاصله مستقل
- [ ] ذخیره، حذف، بازیابی و تعداد نقاط
- [ ] مساحت سه نقطه و چهار نقطه؛ کنترل ترتیب/Zone
- [ ] خروجی و بازشدن DXF در AutoCAD
- [ ] خروجی CSV و واردکردن CSV
- [ ] Backup JSON و Restore
- [ ] چاپ PDF
- [ ] نقشه OSM، satellite، OSRM routing و DXF overlay روی اینترنت
