# UTM Navigator (نسخه یکپارچه آزمایشی)

## قابلیت‌ها
- تبدیل UTM (WGS84) به Lat/Lon و برعکس.
- نمایش مقصد UTM روی نقشه OpenStreetMap.
- دریافت موقعیت GPS با مجوز Android.
- مسیریابی جاده‌ای با سرویس عمومی OSRM (اینترنت لازم است).
- انتخاب نقطه با لمس نقشه و محاسبه مختصات UTM آن.
- ثبت/نمایش/حذف نقاط و خروجی CSV.
- محاسبه فاصله و آزیموت شبکه‌ای UTM.

## ساخت APK در GitHub Actions
1. محتویات پوشه `fixed_project` را در ریشه مخزن قرار دهید.
2. فایل workflow در `.github/workflows/android.yml` است.
3. Actions → Build UTM Navigator APK اجرا کنید (یا روی main commit کنید).
4. Artifact با نام `UTMNavigator-debug-apk` را دانلود کنید.

## محدودیت و نکته تست
نقشه و مسیریابی اینترنت می‌خواهند. OSRM یک سرویس عمومی است و تضمین SLA ندارد. GPS باید با مجوز Location روشن باشد. تست تبدیل مختصات (نقطه مرکزی zone 31 و رفت‌وبرگشت نمونه) در Node انجام شده. تست GPS واقعی و نقشه روی گوشی/محیط Android هنوز لازم است.
